﻿using System;

namespace lab_6
{
    class Program
    {
        static void Main(string[] args)
        {
            Dog dog = new Dog();
            dog.which();
            dog.bark();
        }
    }
}
