﻿using System;
namespace lab_6
{
	public class Animal
	{
		public void which ()
		{
			Console.Write("I'am an Animal ");
		}
	}
}

